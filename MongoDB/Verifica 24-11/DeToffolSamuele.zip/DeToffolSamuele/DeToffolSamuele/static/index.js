$(document).ready(function () {
  $("#btnInvia").on("click", function () {
    let select = $("#lst");
    let request = inviaRichiesta("GET", "/api/dati");
    request.fail(errore);
    request.done(function (data) {
      console.log(data);
      for (const item of data) {
        let option = $("<option>").html(item._id).prop("value", item._id);
        select.append(option);
      }
    });
  });
});
