import * as mongodb from "mongodb";

const mongoClient = mongodb.MongoClient;
const CONNECTION_STRING = "mongodb://127.0.0.1:27017";
const DB_NAME = "5B";


const base64Chars = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J","K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "-", "_"]



//punto 2
mongoClient.connect(CONNECTION_STRING, (err, client) => {
  //  elaborazione verticale --> group, orizzontale --> project
  if (!err) {
    let db = client.db(DB_NAME);
    db.collection("Facts")
      .find(
        { $or: [{ categories:"music" }, { score:{$gt:620}}] },
      ).project({_id:1,score:1,categories:1})
      .toArray()
      .then((data) => console.log("Punto 2", data))
      .catch((err) => console.log("Errore esecuzione query: " + err.message))
      .finally(() => client.close());
  } else {
    console.log("Errore connessione al db: " + err.message);
  }
});


//punto 3
mongoClient.connect(CONNECTION_STRING, (err, client) => {
  //  elaborazione verticale --> group, orizzontale --> project
  if (!err) {
    let db = client.db(DB_NAME);
    db.collection("Facts")
      .insertOne(
        {value:"I'm inserting a new chucknorris's fact",_id : new mongodb.ObjectID(), created_at: new Date().toLocaleDateString(), updated_at : new Date().toLocaleDateString(),icon_url:"https://assets.chucknorris.host/img/avatar/chuck-norris.png",score:0,url:"https://api.chucknorris.io/jokes/"}
      )
      .then((data) => console.log("Punto 3", data))
      .catch((err) => console.log("Errore esecuzione query: " + err.message))
      .finally(() => client.close());
  } else {
    console.log("Errore connessione al db: " + err.message);
  }
});


//punto 4
mongoClient.connect(CONNECTION_STRING, (err, client) => {
  //  elaborazione verticale --> group, orizzontale --> project
  if (!err) {
    let db = client.db(DB_NAME);
    db.collection("Facts")
      .deleteMany(
        {$and:[{updated_at:{$gt:"2021-11-15"}},{score:0}]}
      )
      .then((data) => console.log("Punto 4", data))
      .catch((err) => console.log("Errore esecuzione query: " + err.message))
      .finally(() => client.close());
  } else {
    console.log("Errore connessione al db: " + err.message);
  }
});

//punto 5
mongoClient.connect(CONNECTION_STRING, (err, client) => {
  if (!err) {
      let db = client.db(DB_NAME);
      let collection = db.collection("Facts");
      collection.aggregate([
       { $unwind : "$categories" },
       { $group : {_id : "$categories", mediaScoreBase : { $avg : "$score" }} }, 
       { $addFields : { mediaScore : {$round : ["$mediaScoreBase", 2]} } }])
       .sort({mediaScore : -1, _id : 1})
       .toArray((err, data) => {
            if(!err){
                console.log("Punto 5", data);
            }
            else{
                console.log("Errore esecuzione query " + err.message);
            }
        });
  } else{
      console.log("Errore connessione al db: " + err.message);
  }
});


//punto 6a
mongoClient.connect(CONNECTION_STRING, (err, client) => {
  //  elaborazione verticale --> group, orizzontale --> project
  if (!err) {
    let db = client.db(DB_NAME);
    db.collection("Facts")
      .distinct(
        "categories"
      )
      .then((data) => console.log("Punto 6a", data))
      .catch((err) => console.log("Errore esecuzione query: " + err.message))
      .finally(() => client.close());
  } else {
    console.log("Errore connessione al db: " + err.message);
  }
});